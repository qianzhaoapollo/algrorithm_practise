/*
 * main.cpp
 *
 *  Created on: 2018��5��17��
 *      Author: super
 */

#include "ZhangChong.h"

int main()
{
	ZhangChong zc;

	zc.calculate();

	return 0;
}


